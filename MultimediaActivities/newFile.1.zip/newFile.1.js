export default (await import('vue')).default.extend({
name: 'App',
components: {
HelloWorld
}
});
